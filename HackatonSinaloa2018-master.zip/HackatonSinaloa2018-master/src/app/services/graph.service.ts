import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';

const appToken="205481190051738|0OpRnkX13GQBmjOBnJB7bQGRlwo";

@Injectable()
export class GraphService {

	constructor() {
	}

}
