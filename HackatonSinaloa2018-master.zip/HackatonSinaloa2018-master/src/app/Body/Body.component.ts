import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Body',
  templateUrl: './Body.component.html',
  styleUrls: ['./Body.component.css']
})
export class BodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
